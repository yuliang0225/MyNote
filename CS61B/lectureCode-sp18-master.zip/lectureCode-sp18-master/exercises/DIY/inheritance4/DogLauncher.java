public class DogLauncher {
	public static void main(String[] args) {
		ug.joshh.animal.Dog d = 
		   new ug.joshh.animal.Dog("frank", "terrier", 1.2);
	}
} 