package illuminati;
import syntax3.map.ArrayMap;

/**
 * Created by hug.
 */
public class ChattyMap<K, V> extends ArrayMap<K, V> {
    public static void printSize() {
        //System.out.println(size);
    }
}
