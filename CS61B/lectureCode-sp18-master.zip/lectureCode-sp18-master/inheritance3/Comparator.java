/**
 * Created by jug on 2/7/18.
 */
public interface Comparator<T> {
    public int compare(T x1, T x2);
}
